<h1><p align="center"> Alfa Team Shell </p></h1>

<img src="https://raw.githubusercontent.com/7r0j4ncodeing/Web-Shells/main/.img/3.PNG">

<h1><p align="center"> Alfa 403 forbiddle Shell </p></h1> <h3><p align="center">modify  by  7r0j4n ❤️</p></h3>

## Shell Password : admin

<img src="https://raw.githubusercontent.com/7r0j4ncodeing/Web-Shells/main/.img/4.PNG">

