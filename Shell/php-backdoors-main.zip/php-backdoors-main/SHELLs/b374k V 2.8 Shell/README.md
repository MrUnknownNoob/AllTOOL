<h1><p align="center"> b374k Shell V 2.8 </p></h1>

## Shell Password : admin

<img src="https://raw.githubusercontent.com/7r0j4ncodeing/web-shells/main/.img/7.PNG">

<img src="https://raw.githubusercontent.com/7r0j4ncodeing/Web-Shells/main/.img/8.PNG">



