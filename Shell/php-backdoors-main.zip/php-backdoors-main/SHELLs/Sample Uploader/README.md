<h1><p align="center"> Sample uploader </p></h1>
<p align="center">
<img src="https://raw.githubusercontent.com/7r0j4ncodeing/web-shells/main/.img/6.PNG">
</p>

