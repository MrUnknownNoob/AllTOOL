<h1><p align="center">Priv8 Shell </p></h1>

## password : admin
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/45.jpeg">
