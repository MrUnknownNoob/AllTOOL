<h1><p align="center"> 2018 WSO Shell</p>
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/21.jpeg">
