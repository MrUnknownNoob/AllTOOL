<h1><p align="center">Uploader with Password</p></h1>

# password: admin

<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/56.jpeg">
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/57.jpeg">
