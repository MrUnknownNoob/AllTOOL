<h1><p align="center"> An0n 3xPloiTeR Shell </p></h1>

### password: uexploit
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/27.jpeg">
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/26.jpeg">
