<h1><p align="center">Yanz Web Shell</p></h1>

## password : yanz
<img src="https://raw.githubusercontent.com/1337r0j4n/php-backdoors/main/.img/60.jpeg">
