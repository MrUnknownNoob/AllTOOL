<h1><p align="center"> WSO Web Shell </p></h1>

## password : ghost287
<img src="https://raw.githubusercontent.com/mIcHyAmRaNe/wso-webshell/master/screenshots/wso-welcome.gif">
<img src="https://raw.githubusercontent.com/mIcHyAmRaNe/wso-webshell/master/screenshots/wso-main.png">
