<h1><p align="center"> 404 Not Found Shell </p></h1>

## Shell Password : katib

<img src="https://raw.githubusercontent.com/7r0j4ncodeing/Web-Shells/main/.img/1.PNG">

<img src="https://raw.githubusercontent.com/7r0j4ncodeing/Web-Shells/main/.img/2.PNG">



