<?php

return [
	'title' => __( 'Core', 'it-l10n-ithemes-security-pro' ),
];
