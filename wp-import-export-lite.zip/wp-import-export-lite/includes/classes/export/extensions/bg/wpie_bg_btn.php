<?php
if (!defined('ABSPATH')) {
    die(__("Can't load this file directly", 'wp-import-export-lite'));
}
?>
<div class="wpie_btn wpie_btn_primary wpie_export_bg_process_btn wpie_export_process_btn">
    <i class="fas fa-sync wpie_general_btn_icon " aria-hidden="true"></i>
    <?php esc_html_e('Export In Background', 'wp-import-export-lite'); ?>
</div>