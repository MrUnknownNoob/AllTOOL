<?php

// Exit if accessed directly
//if ( ! defined( 'ABSPATH' ) ) {
//	exit;
//}

require_once 'File.php';
require_once 'Result.php';
require_once 'Scanner.php';
require_once 'Signature.php';
require_once 'SignaturePool.php';
require_once 'HashListPool.php';