(function( $ ) {
	'use strict';

	/**
	 * GuardGiant 
	 */

})( jQuery );
