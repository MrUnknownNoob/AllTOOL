(function( $ ) {
	'use strict';

	/**
	 * GuardGiant Admin
	 */

})( jQuery );
