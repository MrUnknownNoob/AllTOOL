const connectedPlugins = ( state = {} ) => {
	return state;
};

export default connectedPlugins;
