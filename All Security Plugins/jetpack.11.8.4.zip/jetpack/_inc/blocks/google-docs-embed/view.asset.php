<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '82b2e78ff9f7623f609a');
