<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'd31a968e85f04f0d1bcc');
