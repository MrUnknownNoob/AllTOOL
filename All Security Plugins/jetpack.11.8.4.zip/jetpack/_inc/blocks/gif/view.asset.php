<?php return array('dependencies' => array('wp-polyfill'), 'version' => '2b92923d8d27a5562a14');
