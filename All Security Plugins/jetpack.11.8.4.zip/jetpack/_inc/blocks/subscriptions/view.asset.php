<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'fc6283ea8294ee6c2306');
