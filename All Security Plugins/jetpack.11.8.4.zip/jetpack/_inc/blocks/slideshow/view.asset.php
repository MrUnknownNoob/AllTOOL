<?php return array('dependencies' => array('lodash', 'wp-dom-ready', 'wp-escape-html', 'wp-i18n', 'wp-polyfill'), 'version' => '546c1715e1531bfcf166');
