<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '11bd43ea16a7d8a5fef1');
