<?php return array('dependencies' => array('wp-polyfill'), 'version' => '482093c999ab0eb08fcf');
