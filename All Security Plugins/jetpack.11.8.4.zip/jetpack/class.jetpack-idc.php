<?php // phpcs:disable Squiz.Commenting.FileComment.SpacingAfterComment
/**
 * Identity Crisis handler.
 *
 * @deprecated 9.8.0. Functionality moved to the automattic/identity-crisis package.
 * @package automattic/jetpack
 */

 // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
_deprecated_file( basename( __FILE__ ), 'jetpack-9.8' );
