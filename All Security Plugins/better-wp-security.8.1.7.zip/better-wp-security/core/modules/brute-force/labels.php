<?php

return [
	'title' => __( 'Brute Force', 'better-wp-security' ),
];
