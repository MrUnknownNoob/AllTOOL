// BPS jQuery UI Dialog Question Mark help buttons
// Note: each + num has undesirable results - continue to use per div
if (screen.width >= 496) {

jQuery(document).ready(function($){				
	
	var $info1 = $("#bps-modal-content1");     
		$info1.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal1" ).on( "click", function() {
		$info1.dialog( "open" );
	});

	var $info2 = $("#bps-modal-content2");     
		$info2.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal2" ).on( "click", function() {
		$info2.dialog("open");
	});

	var $info3 = $("#bps-modal-content3");     
		$info3.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal3" ).on( "click", function() {
		$info3.dialog("open");
	});

	var $info4 = $("#bps-modal-content4");     
		$info4.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal4" ).on( "click", function() {
		$info4.dialog("open");
	});

	var $info5 = $("#bps-modal-content5");     
		$info5.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal5" ).on( "click", function() {
		$info5.dialog("open");
	});

	var $info6 = $("#bps-modal-content6");     
		$info6.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal6" ).on( "click", function() {
		$info6.dialog("open");
	});

	var $info7 = $("#bps-modal-content7");     
		$info7.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal7" ).on( "click", function() {
		$info7.dialog("open");
	});

	var $info8 = $("#bps-modal-content8");     
		$info8.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal8" ).on( "click", function() {
		$info8.dialog("open");
	});

	var $info9 = $("#bps-modal-content9");     
		$info9.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal9" ).on( "click", function() {
		$info9.dialog("open");
	});

	var $info10 = $("#bps-modal-content10");     
		$info10.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal10" ).on( "click", function() {
		$info10.dialog("open");
	});

	var $info11 = $("#bps-modal-content11");     
		$info11.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal11" ).on( "click", function() {
		$info11.dialog("open");
	});

	var $info12 = $("#bps-modal-content12");     
		$info12.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal12" ).on( "click", function() {
		$info12.dialog("open");
	});

	var $info13 = $("#bps-modal-content13");     
		$info13.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal13" ).on( "click", function() {
		$info13.dialog("open");
	});

	var $info14 = $("#bps-modal-content14");     
		$info14.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal14" ).on( "click", function() {
		$info14.dialog("open");
	});

	var $info15 = $("#bps-modal-content15");     
		$info15.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal15" ).on( "click", function() {
		$info15.dialog("open");
	});

	var $info16 = $("#bps-modal-content16");     
		$info16.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal16" ).on( "click", function() {
		$info16.dialog("open");
	});

	var $info17 = $("#bps-modal-content17");     
		$info17.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal17" ).on( "click", function() {
		$info17.dialog("open");
	});

	var $info18 = $("#bps-modal-content18");     
		$info18.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal18" ).on( "click", function() {
		$info18.dialog("open");
	});

	var $info19 = $("#bps-modal-content19");     
		$info19.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal19" ).on( "click", function() {
		$info19.dialog("open");
	});

	var $info20 = $("#bps-modal-content20");     
		$info20.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal20" ).on( "click", function() {
		$info20.dialog("open");
	});

	var $info21 = $("#bps-modal-content21");     
		$info21.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal21" ).on( "click", function() {
		$info21.dialog("open");
	});

	var $info22 = $("#bps-modal-content22");     
		$info22.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 400,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal22" ).on( "click", function() {
		$info22.dialog("open");
	});

	var $info600 = $("#bps-modal-content600");     
		$info600.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 600,
		 	height: 500,			
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal600" ).on( "click", function() {
		$info600.dialog("open");
	});
});

} else {
	
jQuery(document).ready(function($){				
	
	var $info1 = $("#bps-modal-content1");     
		$info1.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal1" ).on( "click", function() {
		$info1.dialog( "open" );
	});

	var $info2 = $("#bps-modal-content2");     
		$info2.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal2" ).on( "click", function() {
		$info2.dialog("open");
	});

	var $info3 = $("#bps-modal-content3");     
		$info3.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal3" ).on( "click", function() {
		$info3.dialog("open");
	});

	var $info4 = $("#bps-modal-content4");     
		$info4.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal4" ).on( "click", function() {
		$info4.dialog("open");
	});

	var $info5 = $("#bps-modal-content5");     
		$info5.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal5" ).on( "click", function() {
		$info5.dialog("open");
	});

	var $info6 = $("#bps-modal-content6");     
		$info6.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal6" ).on( "click", function() {
		$info6.dialog("open");
	});

	var $info7 = $("#bps-modal-content7");     
		$info7.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal7" ).on( "click", function() {
		$info7.dialog("open");
	});

	var $info8 = $("#bps-modal-content8");     
		$info8.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal8" ).on( "click", function() {
		$info8.dialog("open");
	});

	var $info9 = $("#bps-modal-content9");     
		$info9.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal9" ).on( "click", function() {
		$info9.dialog("open");
	});

	var $info10 = $("#bps-modal-content10");     
		$info10.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal10" ).on( "click", function() {
		$info10.dialog("open");
	});

	var $info11 = $("#bps-modal-content11");     
		$info11.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal11" ).on( "click", function() {
		$info11.dialog("open");
	});

	var $info12 = $("#bps-modal-content12");     
		$info12.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal12" ).on( "click", function() {
		$info12.dialog("open");
	});

	var $info13 = $("#bps-modal-content13");     
		$info13.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal13" ).on( "click", function() {
		$info13.dialog("open");
	});

	var $info14 = $("#bps-modal-content14");     
		$info14.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal14" ).on( "click", function() {
		$info14.dialog("open");
	});

	var $info15 = $("#bps-modal-content15");     
		$info15.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal15" ).on( "click", function() {
		$info15.dialog("open");
	});

	var $info16 = $("#bps-modal-content16");     
		$info16.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal16" ).on( "click", function() {
		$info16.dialog("open");
	});

	var $info17 = $("#bps-modal-content17");     
		$info17.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal17" ).on( "click", function() {
		$info17.dialog("open");
	});

	var $info18 = $("#bps-modal-content18");     
		$info18.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal18" ).on( "click", function() {
		$info18.dialog("open");
	});

	var $info19 = $("#bps-modal-content19");     
		$info19.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal19" ).on( "click", function() {
		$info19.dialog("open");
	});

	var $info20 = $("#bps-modal-content20");     
		$info20.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal20" ).on( "click", function() {
		$info20.dialog("open");
	});

	var $info21 = $("#bps-modal-content21");     
		$info21.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal21" ).on( "click", function() {
		$info21.dialog("open");
	});

	var $info22 = $("#bps-modal-content22");     
		$info22.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal22" ).on( "click", function() {
		$info22.dialog("open");
	});

	var $info600 = $("#bps-modal-content600");     
		$info600.dialog({                            
			dialogClass: "wp-dialog bps-dialog",  
			closeText: "", // remove the close button text
			autoOpen: false,
			show: {
				effect: "blind",
				duration: 500
			},
			hide: {
				effect: "blind",
				duration: 300
			},
			modal: false,
		 	width: 250, 
		 	height: 300, 
		 	position: { 
				my: "center", 
				at: "center" 
			},
		 	buttons: {             
				"Close": function() {                 
					$(this).dialog("close");             
				}         
			}
		});
 
	$( "#bps-open-modal600" ).on( "click", function() {
		$info600.dialog("open");
	});
});
}