jQuery(document).ready(function(){
	jQuery('#checkbox').click(function(){
		jQuery('#new-prefix').toggleClass('hide')
	})
});
