<?php
        if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
        <li>
        <p><span class="dashicons dashicons-flag error"></span> <?php _e( "Unable to update /wp-content/mu-plugins/wp-hide-loader.php. Please make sure /wp-content/mu-plugins/ is writable so the plugin updates the required file.", 'wp-hide-security-enhancer' ) ?></p>
        </li>