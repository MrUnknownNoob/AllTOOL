<?php
        if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
    <li>
    <p><span class="dashicons dashicons-flag error"></span><?php _e("Your server run on WPEngine which works on Nginx rewrite rules, the current version can't create the required rewrite data, please check with WP Hide ", 'wp-hide-security-enhancer') ?> <span class="wph-pro">PRO</span></p>
    </li>