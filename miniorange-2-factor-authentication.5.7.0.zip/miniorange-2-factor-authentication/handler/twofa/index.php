<?php
/**
 * This is index file.
 *
 * @package miniorange-2-factor-authentication/handler/twofa
 */
