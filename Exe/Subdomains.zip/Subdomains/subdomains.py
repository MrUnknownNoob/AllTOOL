import requests

print("""
        Tool Name :: Subdomain FInder
        Author    :: NOOB CODER
        Contact   :: https://cutt.ly/bCJqVpe

""")


def request(url):
    try:
        return requests.get("http://" + url)
    except requests.exceptions.ConnectionError:
        pass

tarurl = str(input("Enter your URL::"))
list = str(input("Enter your List::"))

file =  open(list,'r')
for line in file:
    word = line.strip()
    fullurl = word + "." + tarurl
    response = request(fullurl)
    if response:
        print("Discovered Subdomains at This Link:",fullurl) 

a = input()


