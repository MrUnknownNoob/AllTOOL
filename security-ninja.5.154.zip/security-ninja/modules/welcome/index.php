<?php
// SILENCE