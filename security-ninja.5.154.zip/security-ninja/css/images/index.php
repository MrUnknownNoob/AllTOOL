<?php
// shh - silence is golden