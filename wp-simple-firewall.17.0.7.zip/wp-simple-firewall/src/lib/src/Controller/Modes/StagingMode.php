<?php declare( strict_types=1 );

namespace FernleafSystems\Wordpress\Plugin\Shield\Controller\Modes;

class StagingMode extends BaseMode {

	public const SLUG = 'STAGING';
}