<?php declare( strict_types=1 );

namespace FernleafSystems\Wordpress\Plugin\Shield\Modules\AuditTrail\DB;

/**
 * @property string $rid
 * @property array  $meta_data
 */
class LogRecord extends Logs\Ops\Record {

}