<?php declare( strict_types=1 );

namespace FernleafSystems\Wordpress\Plugin\Shield\Modules\Base\Rest\Route;

use FernleafSystems\Wordpress\Plugin\Shield\Modules\ModConsumer;

class RouteCache extends \FernleafSystems\Wordpress\Plugin\Core\Rest\Route\RouteCache {

	use ModConsumer;
}