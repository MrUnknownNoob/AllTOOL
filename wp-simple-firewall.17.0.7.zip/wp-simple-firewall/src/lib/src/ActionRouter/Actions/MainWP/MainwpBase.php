<?php declare( strict_types=1 );

namespace FernleafSystems\Wordpress\Plugin\Shield\ActionRouter\Actions\MainWP;

use FernleafSystems\Wordpress\Plugin\Shield\ActionRouter\Actions\BaseAction;

abstract class MainwpBase extends BaseAction {

}