<?php declare( strict_types=1 );

namespace FernleafSystems\Wordpress\Plugin\Shield\ActionRouter\Actions\FullPageDisplay;

class StandardFullPageDisplay extends BaseFullPageDisplay {

	public const SLUG = 'display_full_page_standard';
}