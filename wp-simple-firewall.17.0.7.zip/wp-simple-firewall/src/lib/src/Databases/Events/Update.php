<?php declare( strict_types=1 );

namespace FernleafSystems\Wordpress\Plugin\Shield\Databases\Events;

class Update extends \FernleafSystems\Wordpress\Plugin\Shield\Databases\Base\Update {

}