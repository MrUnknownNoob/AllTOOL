<?php declare( strict_types=1 );

namespace FernleafSystems\Wordpress\Plugin\Shield\Databases\FileLocker;

class Insert extends \FernleafSystems\Wordpress\Plugin\Shield\Databases\Base\Insert {

}