<?php

delete_option( 'tfa_version' );

?>