=== WP Content Copy Protection & No Right Click ===
Contributors: wp-buy	
Tags: content, content copy protection, content protection, copy protection, prevent copy, protect blog, image protect, image protection, no right click, plagiarism, secure content, content theft
Requires at least: 4.8
Tested up to: 6.2.2
Stable tag: 3.5.6

This wp plugin protect the posts content from being copied by any other web site author (content copy protection) , you dont want your content to spread without your permission!!


== Description ==
This wp plugin protect the posts content from being copied by any other web site author , you dont want your content to spread without your permission!!
The plugin will keep your posts and home page protected by multiple techniques (JavaScript + CSS), this techniques does not found in any other wordpress plugin and you will own it for free with this plugin
<li><a href="https://www.wp-buy.com/product/wp-content-copy-protection-pro/?src=wp1"><strong>PRO Version Features</strong></li>
**Easy to Install**:
Read the installation steps to find that this plugin does not need any coding or theme editing, just use your mouse..

**Basic Features:**
<ul>
<li>Protect your content from selection and copy. this plugin makes protecting 
your posts extremely simple without yelling at your readers</li>
<li>No one can save images from your site.</li>
<li>No right click or context menu.</li>
<li>Show alert message, Image Ad or HTML Ad on save images or right click.</li>
<li>Disable the following keys&nbsp; CTRL+A, CTRL+C, CTRL+X,CTRL+S or CTRL+V.</li>
<li>Advanced and easy to use control panel.</li>
<li>No one can right click images on your site if you want</li>
</ul>

**The Pro Edition Features include:**
<ul>
<li><a href="https://www.wp-buy.com/product/wp-content-copy-protection-pro/?src=wp2"><strong>PRO version product page</strong></li>
<li>Watermarking</li>
<li>Using htacsess rules</li>
<li>Support jquery overlay protection</li>
<li>Get full Control on Right click or context menu</li>
<li>Show alert messages, when user made right click on images, text boxes, links, plain text.. etc</li>
<li>Admin can exclude Home page Or Single posts from being copy protected </li>
<li>Admin can disable copy protection for admin users.</li>
<li>3 protection layers (JavaScript protection, RightClick protection, CSS protection)</li>
<li>Aggressive image protection (its near impossible for expert users to steal your images !!)</li>
<li>compatible with all major theme frameworks</li>
<li>compatible with all major browsers</li>
<li>Tested in IE9, IE10, Firefox, Google Chrome, Opera</li>
<li>Disables image drag and drop function</li>
<li>Works on smart phones and iphones - solved since 2-10-2015 & updated at 13-11-2015</li>
<li>Ability to set varying levels of protection per page or post.</li>
</ul>

== Screenshots ==
1. WP Content Copy Protection premium admin page
2. Get ful control over context menue
3. Watermarking options
4. Watermarking samples

== Installation ==
**Installation steps**
<ul>
<li>Download the package.</li>
<li>Extract the contents of WP-Content-Copy-Protection.zip to wp-content/plugins/ folder  You should get a folder called WP-Content-Copy-Protection</li>
<li>Activate the Plugin in WP-Admin.</li>
<li>Goto Settings > **WP-Content-Copy-Protection** to configure options.</li>
<li>You will find **4 options** to protect your content,images,homepage and css protection. dont forget to **save** the changes before exit</li>
</ul>

== Changelog ==
= 3.5.6 =
<ul>
<li>Fix some sanitization errors</li>
</ul>
= 3.5.5 =
<ul>
<li>Checking & some text changes</li>
</ul>
= 3.5.4 =
<ul>
<li>Checking with wordpress version 6.2.2</li>
</ul>
= 3.5.3 =
<ul>
<li>Checking with wordpress version 6.2</li>
</ul>
= 3.5.2 =
<ul>
<li>Checking with wordpress version 6.1</li>
</ul>
= 3.5.1 =
<ul>
<li>Fix ReferenceError: on is not defined, e.setAttribute(unselectable, on)</li>
<li>Checking with wordpress version 6.0.1</li>
</ul>
= 3.4.9 =
<ul>
<li>Return to the previous version (3.4.7)with some small fix and new version id (3.4.9) until do more fixes</li>
</ul>
= 3.4.8 =
<ul>
<li>error fix for the main page</li>
</ul>
= 3.4.7 =
<ul>
<li>Checking with wordpress version 6.0</li>
</ul>
= 3.4.6 =
<ul>
<li>Checking with wordpress version 5.9.3</li>
</ul>

= 3.4.5 =
<ul>
<li>security fix for the settings form</li>
</ul>

= 3.4.4 =
<ul>
<li>Checking with wordpress version 5.9</li>
</ul>

= 3.4.3 =
<ul>
<li>Checking with wordpress version 5.8.2</li>
</ul>

= 3.4.2 =
<ul>
<li>Checking some code errors</li>
</ul>

= 3.4.1 =
<ul>
<li>Checking with wordpress version 5.8.1</li>
</ul>

= 3.4.1 =
<ul>
<li>Checking with wordpress version 5.7.2</li>
</ul>

= 3.4 =
<ul>
<li>Important code fix</li>
</ul>

= 3.1.5 =
<ul>
<li>Checking with wordpress version 5.7</li>
<li>Important code fix</li>
</ul>

= 3.1.4 =
<ul>
<li>Checking with wordpress version 5.6</li>
</ul>

= 3.1.3 =
<ul>
<li>Fixed, PHP Notice:  fread(): read of 8192 bytes failed with errno=21 Is a directory in /wp-includes/functions.php on line 6030</li>
</ul>

= 3.1.2 =
<ul>
<li>Important fix for this error, PHP Warning: array_key_exists() expects parameter 2 to be array, preventer-index.php on line 691 </li>
<li>Top icon bar color converted to new very nice color - green</li>
<li>Testing with wordpress 5.5.3 new version</li>
</ul>

= 3.1 =
<ul>
<li>Now compatible with (elemenator page builder) plugin</li>
<li>Now compatible with (siteorigin live editor page builder) plugin</li>
<li>Now compatible with (WordPress Page Builder – Beaver Builder) plugin</li>
<li>Now compatible with (Wordpress internal preview mode)</li>
<li>New control panel (restore defaults) button added</li>
<li>New control panel (preview alert message) button added</li>
<li>New name for the top bar icon to fix its default choice in the previous version</li>
<li>Translation file updated</li>
<li>Some fixes</li>
</ul>

= 2.9 =
<ul>
<li>Important fix for content editable tags</li>
<li>Now compatible with wpDiscuz plugin & some chat wordpress plugins</li>
<li>Top bar icon  has been returned, as it was inside previous version 2.6</li>
<li>New option inside main settings to control the visibility of the top bar icon</li>
<li>Stop the auto loading for the alert (warning.png) icon</li>
<li>Some linguistic mistakes were corrected</li>
</ul>

= 2.8.1 =
<ul>
<li>Important fix for 2.7 update</li>
<li>Add links to dismiss the new start page links</li>
</ul>
= 2.7 =
<ul>
<li>Disable (CTRL + Shift + I) developer tools shortcut key</li>
<li>Remove recommended plugins section from admin page</li>
<li>Add one starting page for all of our plugins</li>
<li>Code fix</li>
</ul>
= 2.6 =
<ul>
<li>Test all features with wordpress version 5.5</li>
</ul>
= 2.5 =
<ul>
<li>Code fix</li>
</ul>
= 2.4 =
<ul>
<li>Safari update and fix</li>
<li>checking with new wordpress version</li>
<li>Admin page Fix</li>
</ul>
= 2.3 =
<ul>
<li>Copy paste password to log in fields and any other text field is now possible</li>
<li>Some script fixes</li>
<li>Admin page Fix (mailing list join message will show your email before submit)</li>
<li>Admin page Fix (Our other products list is ready to go)</li>
</ul>
= 2.2 =
<ul>
<li>Admin page Fix</li>
</ul>
= 2.1 =
<ul>
<li>Fix iphone & ipad posts protection</li>
<li>Premium feature unlocked!! the second option inside CSS protection tab</li>
<li>"Review us" admin dismissable notice added</li>
</ul>
= 1.9 =
<ul>
<li>Translation slug is now the same as the plugin slug</li>
<li>Arabic translation file included inside the plugin language folder and its also included on wordpress translation plugin page</li>
</ul>
= 1.8 =
<ul>
<li>Translation is now supported</li>
<li>wp-content-copy-protector.pot Template translation file included</li>
</ul>	
= 1.7.3 =
<ul>
<li>Checking with the last update</li>
<li>Unwanted ad removed</li>
</ul>	
= 1.7.2 =
<ul>
<li>Fix the error Undefined index: prnt_scr_msg in preventer-index.php on line 171</li>
</ul>	
= 1.7.1 =
<ul>
<li>Add dismiss button to the end of upgrade message</li>
</ul>	
= 1.7 =
<ul>
<li>New option to show Print preview message instead of showing page content when user try to print your page using CTRL+P key</li>
<li>Fixes inside admin page layout</li>
</ul>	
= 1.6.2 =
<ul>
<li>Fix Fatal error: Cannot redeclare plugin_add_settings_link()</li>
</ul>
= 1.6 =
<ul>
<li>JQuery important hotfix</li>
<li>Sanetization for all input and output</li>
</ul>
= 1.5.0.5 =
<ul>
<li>Internet Explorer important hotfix</li>
<li>Testing on wordpress 4.4.2 new version</li>
</ul>
= 1.5.0.4 =
<ul>
<li>Auto remove image url's</li>
<li>Fix javascript errors</li>
</ul>
= 1.5.0.3 =
<ul>
<li>Adding adminbar link and icon redirecting you to the plugin settings page</li>
<li>Adding settings link into the plugins list page</li>
</ul>
= 1.5.0.2 =
<ul>
<li>Adding isset() function to all variables</li>
<li>Improving alert message</li>
<li>Fixing CTRL + U issue</li>
<li>Fixing CSS tricks</li>
</ul>
= 1.5.0.1 =
<ul>
<li>Fixing error (Warning: join(): Invalid arguments passed in /home/retailmakeover/public_html/wp-includes/post-template.php on line 478)</li>
</ul>
= 1.4.0.1 =
<ul>
<li>Admin can disable copy protection for logged in/admin users</li>
<li>disable the possible shortcut keys for copying the Text</li>
<li>You can also choose where this Plugin should work like All Pages (including Home Page and all other Pages & Posts) or Home Page or Custom Pages/Posts using the Settings Page options.</li>
<li>Multiple Text and Image Protection methods</li>
<li>Advanced Image Protection using Responsive Lightbox</li>
<li>Protect your Text and Images by Disabling the Mouse Right Click and Possible Shortcut Keys for Cut (CTRL+x), Copy (CTRL+c), Paste (CTRL+v), Select All(CTRL+a), View Source (CTRL+u) etc.</li>
<li>control the protection to be on users only (if admin here dont protect)</li>
<li>Option to Display Alert Message on Mouse Right Click.</li>
<li>Enable Right Click on Hyperlink Option Added</li>
<li>Right click problem fixed on static pages</li>
<li>New flat interface</li>
</ul>
= 1.0 =
<ul>
<li>initial version</li>
<li>static pages bug fixed</li>
<li>home page problem fixed</li>
<li>Add new Style</li>
</ul>