<div>
	<iframe style="width: 100%; min-height: 100vh;" src="<?=esc_url($this->account->authenticatedUrl('/malcare/access'))?>"/>
</div>