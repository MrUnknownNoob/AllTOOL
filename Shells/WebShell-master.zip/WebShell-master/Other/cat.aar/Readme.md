#axis2 利用小工具cat.aar  

Author:园长  
文章url:http://p2j.cn/?p=1548  
[下载文章的pdf](https://raw.githubusercontent.com/tennc/webshell/master/other/cat.aar/axis2%20%E5%88%A9%E7%94%A8%E5%B0%8F%E5%B7%A5%E5%85%B7cat.pdf)
