#pragma once

#ifndef STDAFX

#define STDAFX

#include "zend_config.w32.h" 
#include "php.h"

#endif