Windows:
http://stackoff.ru/pishem-rasshirenie-bekdor-dlya-php/

Linux:  
`sudo apt-get install php5-dev`  
`phpize && ./configure && make`