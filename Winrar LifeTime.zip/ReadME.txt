WinRAR Lifetime License: 

Hold windows key and r or just search on windows search "run" and type : C:\Program Files\WinRAR to get into the WinRAR directory.

Copy and paste the rarreg.key into this directory and confirm it as admin.