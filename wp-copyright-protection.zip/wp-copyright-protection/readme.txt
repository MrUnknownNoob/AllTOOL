=== WP-Copyright-Protection ===
Contributors: dave.ligthart
Donate link: http://www.daveligthart.com
Tags: copyright,protection,copy,protect
Requires at least: 2.3
Tested up to: 3.5
Stable tag: trunk

Simple copyright protection for your images and text.

== Description ==

A simple way to protect the content on your website. For most browsers: disables text copy, image copy and will keep your site out of an iframe.

This plugin is clean and easy.

WordPress MU, PHP4 and safe_mode compatible.

== Installation ==

Install, activate and you're done.

You're all set!

Note: If you have feedback or suggestions;
Just post a mail to: dligthart@gmail.com?subject=wp-copyright-protection

Thanks for downloading this great plugin!

== Changelog ==

= Version 1.0 =

First version.

= Version 1.1 =

Disable save image in iOS.
Disable imagetoolbar in IE6.

= Version 1.2 =

Unprotect pages.
Disable copyright protection for logged in users.
Added settings page.

= Version 1.3 =

Prevent image save iOS.

= Version 1.4 =

Fixed Firefox dropdown issue.
