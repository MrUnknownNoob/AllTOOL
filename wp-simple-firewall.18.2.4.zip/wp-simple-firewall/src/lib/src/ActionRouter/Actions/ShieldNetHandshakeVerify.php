<?php declare( strict_types=1 );

namespace FernleafSystems\Wordpress\Plugin\Shield\ActionRouter\Actions;

class ShieldNetHandshakeVerify extends LicenseHandshakeVerifyKeyless {

	public const SLUG = 'snapi_handshake';
}