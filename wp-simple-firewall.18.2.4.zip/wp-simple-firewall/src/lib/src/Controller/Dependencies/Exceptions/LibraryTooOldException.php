<?php declare( strict_types=1 );

namespace FernleafSystems\Wordpress\Plugin\Shield\Controller\Dependencies\Exceptions;

class LibraryTooOldException extends \Exception {

}