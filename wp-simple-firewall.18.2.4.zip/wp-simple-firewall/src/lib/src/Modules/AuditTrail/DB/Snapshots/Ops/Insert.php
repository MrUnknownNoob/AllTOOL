<?php declare( strict_types=1 );

namespace FernleafSystems\Wordpress\Plugin\Shield\Modules\AuditTrail\DB\Snapshots\Ops;

class Insert extends \FernleafSystems\Wordpress\Plugin\Core\Databases\Base\Insert {

}