<?php declare( strict_types=1 );

namespace FernleafSystems\Wordpress\Plugin\Shield\Modules\AuditTrail\DB\Meta\Ops;

use FernleafSystems\Wordpress\Plugin\Core\Databases\Base;

class Select extends Base\Select {

	use Common;
}