<?php declare(strict_types=1);

namespace WPMU_DEV\Defender\Vendor\PhpDocReader;

/**
 * We stumbled upon an invalid class/property/method annotation.
 */
class AnnotationException extends \Exception
{
}