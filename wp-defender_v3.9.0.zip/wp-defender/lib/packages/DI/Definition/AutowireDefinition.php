<?php

declare(strict_types=1);

namespace WPMU_DEV\Defender\Vendor\DI\Definition;

/**
 * @author Matthieu Napoli <matthieu@mnapoli.fr>
 */
class AutowireDefinition extends ObjectDefinition
{
}