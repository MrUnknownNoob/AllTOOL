<?php

namespace WPMU_DEV\Defender\Vendor\Psr\Container;

/**
 * Base interface representing a generic exception in a container.
 */
interface ContainerExceptionInterface
{
}